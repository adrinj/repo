#!/usr/local/bin/ruby -w
puts "Hello world"